<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');



class Email_model extends CI_Model
{
    
    /*	
	 *	Developed by    : Active IT zone
	 *	Date	        : 14 July, 2015
	 *	Active Supershop eCommerce CMS
	 *	http://codecanyon.net/user/activeitezone
     *  Last Modified   : 18 January, 2017 
	 */
    
    function __construct()
    {
        parent::__construct();
    }
    
    
    function password_reset_email($account_type = '', $id = '', $pass = '')
    {
        $this->load->database();

        $from       = $this->db->get_where('general_settings', array('type' => 'smtp_user'))->row()->value;
        $from_name  = $this->db->get_where('general_settings', array('type' => 'system_name'))->row()->value;
        
        $query      = $this->db->get_where($account_type, array($account_type . '_id' => $id));

        if ($query->num_rows() > 0) {
            $msg        = "Your account type is : " . $account_type . "<br />";
            $msg       .= "Your password is : " . $pass . "<br />";
            $sub        = "Password reset request";
            $to         = $query->row()->email;
            $send_mail  = $this->do_email($from, $from_name, $to, $sub, $msg);
            return $send_mail;
        } 
        else {
            return false;
        }
    }
    function status_email($account_type = '', $id = '')
    {
        $this->load->database();

        $from       = $this->db->get_where('general_settings', array('type' => 'smtp_user'))->row()->value;
        $from_name  = $this->db->get_where('general_settings', array('type' => 'system_name'))->row()->value;
        
        $query = $this->db->get_where($account_type, array($account_type . '_id' => $id));

        if ($query->num_rows() > 0) {
            $msg = "Your account type is : " . $account_type . "<br />";
            if($query->row()->status == 'approved'){
                $msg .= "Your account is : Approved<br />";
            } else {
                $msg .= "Your account is : Postponed<br />";
            }
            $sub        = "Account Status Change";
            $to   = $query->row()->email;

            $send_mail  = $this->do_email($from, $from_name, $to, $sub, $msg);
            return $send_mail;
        } 
        else {
            return false;
        }
    }
    
    
    function membership_upgrade_email($vendor)
    {
        $this->load->database();
        $account_type = 'vendor';

        $from       = $this->db->get_where('general_settings', array('type' => 'smtp_user'))->row()->value;
        $from_name  = $this->db->get_where('general_settings', array('type' => 'system_name'))->row()->value;
        
        $query = $this->db->get_where($account_type, array($account_type . '_id' => $vendor));

        if ($query->num_rows() > 0) {
            if($query->row()->membership == '0'){
                $msg    = "Your Membership Type is reduced to : Default <br />";
            } 
            else {
                $msg    = "Your Membership Type is upgraded to : " . $this->db->get_where('membership',array('membership_id'=>$query->row()->membership))->row()->title . "<br />";
            }
            $sub = "Membership Upgrade";
            $to  = $query->row()->email;

            $send_mail  = $this->do_email($from, $from_name, $to, $sub, $msg);
            return $send_mail;
        } 
        else {
            return false;
        }
    }
    
    function account_opening($account_type = '', $email = '', $pass = '')
    {
        $this->load->database();
        
        $from = $this->db->get_where('general_settings', array('type' => 'smtp_user'))->row()->value;
        $from_name  = $this->db->get_where('general_settings', array('type' => 'system_name'))->row()->value;
        $to   = $email;

        $query = $this->db->get_where($account_type, array('email' => $email));
        
        if ($query->num_rows() > 0) {
            $password  = $pass;
            $msg = "Thanks for your registration in : " . $from_name . "<br />";
            $msg .= "Your account type is : " . $account_type . "<br />";
            $msg .= "Your password is : " . $pass . "<br />";
            if($account_type == 'vendor'){
                $msg .= "login here: <a href='".base_url()."index.php/vendor/'>".base_url()."index.php/vendor</a>";
                $msg .= "<br>Your account is now being reviewed. Please wait for Admin approval.";
            }
            if($account_type == 'user'){

            }
            if($account_type == 'admin'){
                $msg .= "login here: <a href='".base_url()."index.php/admin/'>".base_url()."index.php/admin</a>";
            }
            $sub = "Account Opening";
            
            $send_mail = $this->do_email($from, $from_name, $to, $sub, $msg); //returns boolean data
            return $send_mail;
        } 
        else {
            return false;
        }
    }
    
    
    
    function newsletter($title = '', $text = '', $email = '', $from = '')
    {
        $from_name  = $this->db->get_where('general_settings', array('type' => 'system_name'))->row()->value;
        $this->do_email($from, $from_name, $email, $title, $text);
    }
    
    
    
    /***custom email sender****/
    
    function do_email($from = '', $from_name = '', $to = '', $sub ='', $msg ='')
    {

        $this->load->library('email');

        $this->email->set_newline("\r\n");
        $this->email->from($from, $from_name);
        $this->email->to($to);        
        $this->email->subject($sub);
        $this->email->message($msg);
        
        if($this->email->send()){
            return true;
        }else{
            return false;
        }
        //echo $this->email->print_debugger();
    }
    
    
    
}